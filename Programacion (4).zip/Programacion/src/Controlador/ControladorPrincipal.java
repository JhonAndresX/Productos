/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.DetalleFac;
import Modelo.EncabezadoFac;
import Modelo.ModeloDetalle;
import Modelo.ModeloFactura;
import Modelo.ModeloPersona;
import Modelo.ModeloProducto;
import Modelo.Persona;
import Modelo.Producto;
import Vista.CrudProducto;
import Vista.Factura;
import Vista.MenuPrincipal;
import Vista.VistaPersonas;

/**
 *
 * @author ASUS
 */
public class ControladorPrincipal {

    MenuPrincipal vistaprincipal;

    public ControladorPrincipal(MenuPrincipal vistaprincipal) {
        this.vistaprincipal = vistaprincipal;
        vistaprincipal.setVisible(true);
    }

    public void iniciacontrol() {
        vistaprincipal.getBtnPersona().addActionListener(l -> VistaPersonas());
        vistaprincipal.getBtnProductos().addActionListener(l -> CrudProducto());
        vistaprincipal.getBtnFac().addActionListener(l -> VistaFactura());
    }

    public void VistaPersonas() {
        Modelo.ModeloPersona model = new ModeloPersona();
        Vista.VistaPersonas vista = new VistaPersonas();
        Modelo.Persona miper = new Persona();
        Controlador.ControladorPersona control = new ControladorPersona(model, vista);
        control.iniciaControl();
        this.vistaprincipal.dispose();

    }

    public void VistaFactura() {
        Modelo.ModeloFactura modelFa = new ModeloFactura();
        Modelo.ModeloDetalle modelDe = new ModeloDetalle();
        Modelo.ModeloProducto modelpro = new ModeloProducto();
        Modelo.ModeloPersona modelper = new ModeloPersona();
        Vista.Factura vista = new Factura();
        Modelo.DetalleFac enc = new DetalleFac();
        Modelo.EncabezadoFac det = new EncabezadoFac();
        Controlador.ControladorFactura control1 = new ControladorFactura(modelDe, modelFa, modelpro, modelper, vista);

        control1.iniciaControl();
        this.vistaprincipal.dispose();

    }

    public void CrudProducto() {
        Modelo.ModeloProducto model = new ModeloProducto();
        Vista.CrudProducto vista = new CrudProducto();
        Modelo.Producto mipro = new Producto();
        Controlador.ControladorProducto control = new ControladorProducto(model, vista);
        control.iniciaControl();
        this.vistaprincipal.dispose();
    }
}
