/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ModeloDetalle;
import Modelo.ModeloFactura;
import Modelo.DetalleFac;
import Modelo.EncabezadoFac;
import Modelo.ModeloPersona;
import Modelo.ModeloProducto;
import Modelo.Persona;
import Modelo.Producto;
import Vista.Factura;
import Vista.MenuPrincipal;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorFactura {

    private ModeloDetalle modeloDet;
    private ModeloFactura modeloFac;
    private ModeloPersona modeloPer;
    private ModeloProducto modeloPro;
    private Factura vista;

    public ControladorFactura(ModeloDetalle modeloDet, ModeloFactura modeloFac, ModeloProducto modeloPro, ModeloPersona modeloPer, Factura vista) {
        this.modeloDet = modeloDet;
        this.modeloFac = modeloFac;
        this.modeloPro = modeloPro;
        this.modeloPer = modeloPer;
        this.vista = vista;
        vista.setVisible(true);
        cargaFactura();
        cargaProductos();
        cargaPersonas();
        vista.getTxtProducto().setEnabled(false);
        vista.getTxtPrecio().setEnabled(false);
        vista.getTxtCliente().setEnabled(false);
        vista.getTxtTotalDe().setEnabled(false);

    }

    public void iniciaControl() {
        vista.getBtnConsultar().addActionListener(o -> buscar());
        vista.getBtnCrear().addActionListener(l -> abrirDialogo("Crear"));
        vista.getBtnEditar().addActionListener(l -> abrirDialogo("Editar"));
        vista.getBtnRemover().addActionListener(l -> abrirDialogo("Eliminar"));
        vista.getBtnLimpiar().addActionListener(l -> limpiarbusqueda());
        vista.getBtnAceptar().addActionListener(l -> crearEditarFactura());
        vista.getBtnSalir().addActionListener(l -> salir());

        vista.getTblPersonaDLG().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                LlenarDatosPersona();
            }
        });
        vista.getTblProductoDLG().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                LlenarDatosProducto();
            }
        });
        vista.getSpnCantidad().addChangeListener(e -> {
            double numero1 = Double.parseDouble(vista.getTxtPrecio().getText());
            double numero2 = Double.parseDouble(vista.getSpnCantidad().getValue().toString());
            double resultado = numero1 * numero2;
            vista.getTxtTotalDe().setText(String.valueOf(resultado));
        });
    }

    private void limpiarbusqueda() {
        vista.getTxtBuscar().setText("");
        cargaFactura();
    }

    private void buscar() {
        List<EncabezadoFac> listaEncabezado = modeloFac.listaEncabezado();
        List<DetalleFac> listaDetalle = modeloDet.listadetalle();
        String idBuscado = vista.getTxtBuscar().getText();

        DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("IdEncabezado");
        modeloTabla.addColumn("IdDetalle");
        modeloTabla.addColumn("IdCliente");
        modeloTabla.addColumn("Producto");
        modeloTabla.addColumn("Cantidad");
        modeloTabla.addColumn("Total");

        for (EncabezadoFac p : listaEncabezado) {
            for (DetalleFac d : listaDetalle) {
                if (p.getIdfactura().equals(idBuscado)) {
                    Object[] fila = {
                        p.getIdfactura(),
                        d.getIddetalle(),
                        p.getCliente(),
                        d.getProducto(),
                        d.getCantidad(),
                        p.getTotal()};
                    modeloTabla.addRow(fila);
                }
            }
        }

        vista.getTblFactura().setModel(modeloTabla);
    }

    private void crearEditarFactura() {
        if (vista.getDialogFac().getTitle().contentEquals("Crear")) {
            ModeloFactura p = new ModeloFactura();
            ModeloDetalle d = new ModeloDetalle();

            String codigo = vista.getTxtEncabezado().getText();
            String codigodetalle = vista.getTxtidDetalle().getText();

            if (codigoExiste(codigo)) {
                JOptionPane.showMessageDialog(null, "El código ya existe. Por favor, ingrese un código diferente.");
            } else if (!validarCodigo(codigo)) {
                JOptionPane.showMessageDialog(null, "El código debe tener 5 DÍGITOS.");
            } else if (!validarCodigo(codigodetalle)) {
                JOptionPane.showMessageDialog(null, "El código del detalle debe tener 5 DÍGITOS.");
            } else {
                p.setIdfactura(codigo);
                d.setIddetalle(codigodetalle);
                d.setIdfactura(codigo);
                p.setCliente(vista.getTxtCliente().getText());
                d.setProducto(vista.getTxtProducto().getText());
                p.setCliente(vista.getTxtCliente().getText());
                d.setCantidad(Integer.parseInt(vista.getSpnCantidad().getValue().toString()));
                d.setPrecio(Double.parseDouble(vista.getTxtPrecio().getText()));
                d.setTotal(Double.parseDouble(vista.getTxtTotalDe().getText()));
                p.setTotal(Double.parseDouble(vista.getTxtTotalDe().getText()));

                java.sql.Date fechan = java.sql.Date.valueOf(LocalDate.of(
                        vista.getTxtFecha().getDate().getYear() + 1900,
                        vista.getTxtFecha().getDate().getMonth() + 1,
                        vista.getTxtFecha().getDate().getDate()));
                p.setFecha(fechan);
                if (p.grabarEncabezado()) {
                    if (d.grabarDetalle()) {

                        JOptionPane.showMessageDialog(vista, "DATOS CREADOS");
                        vista.getDialogFac().setVisible(false);
                        cargaFactura();
                        limpiar();
                    } else {
                        JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
                    }
                }
            }
        } else if (vista.getDialogFac().getTitle().contentEquals("Editar")) {
            ModeloFactura p = new ModeloFactura();
            ModeloDetalle d = new ModeloDetalle();

            if (vista.getTxtCliente().getText().equals("") || vista.getTxtidDetalle().getText().equals("") || vista.getTxtEncabezado().getText().equals("") || vista.getTxtPrecio().getText().equals("")) {
                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");
            } else {
                String codigo = vista.getTxtEncabezado().getText();
                String codigodetalle = vista.getTxtidDetalle().getText();

                if (!validarCodigo(codigo)) {
                    JOptionPane.showMessageDialog(null, "El código debe tener 5 DÍGITOS.");
                } else if (!validarCodigo(codigodetalle)) {
                    JOptionPane.showMessageDialog(null, "El código del detalle debe tener 5 DÍGITOS.");
                } else {
                    p.setIdfactura(codigo);
                    d.setIddetalle(codigodetalle);
                    d.setIdfactura(codigo);
                    p.setCliente(vista.getTxtCliente().getText());
                    d.setProducto(vista.getTxtProducto().getText());
                    p.setCliente(vista.getTxtCliente().getText());
                    d.setCantidad(Integer.parseInt(vista.getSpnCantidad().getValue().toString()));
                    d.setPrecio(Double.parseDouble(vista.getTxtPrecio().getText()));
                    d.setTotal(Double.parseDouble(vista.getTxtTotalDe().getText()));
                    p.setTotal(Double.parseDouble(vista.getTxtTotalDe().getText()));

                    java.sql.Date fechan = java.sql.Date.valueOf(LocalDate.of(
                            vista.getTxtFecha().getDate().getYear() + 1900,
                            vista.getTxtFecha().getDate().getMonth() + 1,
                            vista.getTxtFecha().getDate().getDate()));
                    p.setFecha(fechan);
                    if (p.ModificarEncabeza()) {
                        if (d.ModificarDetalle()) {

                            JOptionPane.showMessageDialog(vista, "DATOS ACTUALIZADOS");
                            vista.getDialogFac().setVisible(false);
                            cargaFactura();
                            limpiar();
                        } else {
                            JOptionPane.showMessageDialog(vista, "ERROR AL ACTUALIZAR DATOS");
                        }
                    }
                }
            }
        } else if (vista.getDialogFac().getTitle().contentEquals("Eliminar")) {
            ModeloFactura p = new ModeloFactura();
            ModeloDetalle d = new ModeloDetalle();

            p.setIdfactura(vista.getTxtEncabezado().getText());
            d.setIddetalle(vista.getTxtidDetalle().getText());
            if (p.EliminarEncabeza()) {
                if (d.EliminarDetalle()) {

                    JOptionPane.showMessageDialog(vista, "DATOS ELIMINADOS");
                    vista.getDialogFac().setVisible(false);
                    cargaFactura();
                    limpiar();
                } else {
                    JOptionPane.showMessageDialog(vista, "ERROR AL ELIMINAR DATOS");
                }
            }
        }
    }

    private void limpiar() {
        vista.getTxtEncabezado().setText("");
        vista.getTxtFecha().setDate(null);
        vista.getTxtCliente().setText("");
        vista.getTxtidDetalle().setText("");
        vista.getTxtProducto().setText("");

        vista.getSpnCantidad().setValue(0);
        vista.getTxtPrecio().setText("");

        vista.getTxtTotalDe().setText("");

    }

    private void abrirDialogo(String ce) {
        vista.getDialogFac().setLocation(0, 0);
        vista.getDialogFac().setSize(1350, 720);
        vista.getDialogFac().setTitle(ce);
        vista.getDialogFac().setVisible(true);
        if (vista.getDialogFac().getTitle().contentEquals("Crear")) {
            // Código para inicializar la creación
        } else if (vista.getDialogFac().getTitle().contentEquals("Editar")) {
            LlenarDatos();
        } else if (vista.getDialogFac().getTitle().contentEquals("Eliminar")) {
            LlenarDatos();
        }
    }

    private void cargaFactura() {
        DefaultTableModel mJtable = (DefaultTableModel) vista.getTblFactura().getModel();
        mJtable.setNumRows(0);
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();
        List<DetalleFac> listaD = modeloDet.listadetalle();
        for (EncabezadoFac p : listaP) {
            for (DetalleFac d : listaD) {
                if (p.getIdfactura().equals(d.getIdfactura())) {
                    String[] rowData = {p.getIdfactura(), d.getIddetalle(), p.getCliente(), d.getProducto(), String.valueOf(d.getCantidad()), String.valueOf(p.getTotal())};
                    mJtable.addRow(rowData);
                }
            }
        }
    }

    private void cargaPersonas() {
        DefaultTableModel mJtable1;
        mJtable1 = (DefaultTableModel) vista.getTblPersonaDLG().getModel();
        mJtable1.setNumRows(0);
        List<Persona> listper = modeloPer.listarPersonas();
        listper.stream().forEach(p -> {
            String[] rowData = {p.getId_persona(), p.getNombres(), p.getApellido()};
            mJtable1.addRow(rowData);
        }
        );
    }

    public void cargaProductos() {
        DefaultTableModel mJtable2 = (DefaultTableModel) vista.getTblProductoDLG().getModel();
        mJtable2.setNumRows(0);
        List<Producto> listaP = modeloPro.listarProductos();
        for (Producto p : listaP) {
            String[] rowData = {
                p.getCodigo(),
                p.getNombre(),
                p.getCantidad(),
                p.getPrecio()
            };
            mJtable2.addRow(rowData);
        }
    }

    public void LlenarDatosPersona() {

        List<Persona> listper = modeloPer.listarPersonas();
        int selectedRow = vista.getTblPersonaDLG().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para que los datos se llenen, debe seleccionar un elemento de la tabla");
        } else {
            String selectedId = vista.getTblPersonaDLG().getValueAt(selectedRow, 0).toString();
            Optional<Persona> matchingPersona = listper.stream()
                    .filter(p -> selectedId.equals(p.getId_persona()))
                    .findFirst();

            if (matchingPersona.isPresent()) {
                Persona p = matchingPersona.get();
                vista.getTxtCliente().setText(p.getNombres());

            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void LlenarDatosProducto() {

        List<Producto> listper = modeloPro.listarProductos();
        int selectedRow = vista.getTblProductoDLG().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para que los datos se llenen, debe seleccionar un elemento de la tabla");
        } else {
            String selectedId = vista.getTblProductoDLG().getValueAt(selectedRow, 0).toString();
            Optional<Producto> matchingProducto = listper.stream()
                    .filter(p -> selectedId.equals(p.getCodigo()))
                    .findFirst();

            if (matchingProducto.isPresent()) {
                Producto p = matchingProducto.get();
                vista.getTxtPrecio().setText(p.getPrecio());

                vista.getTxtProducto().setText(p.getNombre());

            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void LlenarDatos() {
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();
        List<DetalleFac> listaD = modeloDet.listadetalle();
        int selectedRow = vista.getTblFactura().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para llenar los datos, debe seleccionar un elemento de la tabla.");
        } else {
            String selectedId = vista.getTblFactura().getValueAt(selectedRow, 0).toString();
            String selectedid1 = vista.getTblFactura().getValueAt(selectedRow, 1).toString();
            Optional<EncabezadoFac> matchingEncabezado = listaP.stream()
                    .filter(p -> selectedId.equals(p.getIdfactura()))
                    .findFirst();
            Optional<DetalleFac> matchingDetalle = listaD.stream()
                    .filter(d -> selectedid1.equals(d.getIddetalle())).findFirst();

            if (matchingEncabezado.isPresent() && matchingDetalle.isPresent()) {
                EncabezadoFac p = matchingEncabezado.get();
                DetalleFac d = matchingDetalle.get();
                vista.getTxtEncabezado().setText(p.getIdfactura());
                vista.getTxtFecha().setDate(p.getFecha());
                vista.getTxtCliente().setText(p.getCliente());
                vista.getTxtidDetalle().setText(d.getIddetalle());
                vista.getTxtProducto().setText(d.getProducto());
                vista.getTxtPrecio().setText(String.valueOf(d.getPrecio()));
                vista.getSpnCantidad().setValue(d.getCantidad());
                vista.getTxtTotalDe().setText(String.valueOf(p.getTotal()));
                vista.getTxtEncabezado().setEnabled(false);
             //   vista.getTxtidDetalle().setEnabled(false);
                vista.getTxtProducto().setEnabled(false);
                vista.getTxtPrecio().setEnabled(false);
                vista.getTxtCliente().setEnabled(false);
                vista.getTxtTotalDe().setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void salir() {
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);

        Controlador.ControladorPrincipal control = new ControladorPrincipal(menu);
        control.iniciacontrol();
        this.vista.dispose();
    }

    private boolean codigoExiste(String codigo) {
        List<EncabezadoFac> listaP = modeloFac.listaEncabezado();

        for (EncabezadoFac encabezado : listaP) {
            if (encabezado.getIdfactura().equals(codigo)) {
                return true;
            }
        }

        return false;
    }

    private boolean codigoExiste1(String codigo) {
        List<DetalleFac> listaD = modeloDet.listadetalle();

        for (DetalleFac detalle : listaD) {
            if (detalle.getIddetalle().equals(codigo)) {
                return true;
            }
        }

        return false;
    }

    public boolean validarNombre(String nombre) {
        return nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,50}");
    }

    public boolean validarDescripcion(String descripcion) {
        return descripcion.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,99}");
    }

    public boolean validarCodigo(String codigo) {
        return codigo.matches("\\d{5}");
    }

    public boolean validarPrecio(String precio) {
        return precio.matches("\\d+(\\.\\d+)?");
    }

    public boolean validarCantidad(String cantidad) {
        return cantidad.matches("\\d+");
    }
}
