/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ModeloProducto;
import Modelo.Producto;
import Vista.CrudProducto;
import Vista.MenuPrincipal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import javax.swing.JOptionPane;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS
 */
public class ControladorProducto {

    private ModeloProducto modelo;
    private CrudProducto vista;

    public ControladorProducto(ModeloProducto modelo, CrudProducto vista) {
        this.modelo = modelo;
        this.vista = vista;
        vista.setVisible(true);
        cargaProductos();
    }

    public void iniciaControl() {
        vista.getBtnConsultar().addActionListener(o -> buscar());
        vista.getBtnCrear().addActionListener(l -> abrirDialogo("Crear"));
        vista.getBtnEditar().addActionListener(l -> abrirDialogo("Editar"));
        vista.getBtnRemover().addActionListener(l -> abrirDialogo("Eliminar"));
        vista.getBtnLimpiar().addActionListener(l -> limpiarbusqueda());
        vista.getBtnAceptar().addActionListener(l -> crearEditarProducto());
        vista.getBtnSalir().addActionListener(l -> salir());
    }

    private void limpiarbusqueda() {
        vista.getTxtBuscar().setText("");
        cargaProductos();
    }

    private void buscar() {
        List<Producto> listpro = modelo.listarProductos();
        String idBuscado = vista.getTxtBuscar().getText();

        DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Codigo");
        modeloTabla.addColumn("Nombre Producto");
        modeloTabla.addColumn("Descripcion Producto");
        modeloTabla.addColumn("Cantidad Producto");
        modeloTabla.addColumn("Precio Producto");

        for (Producto p : listpro) {
            if (p.getCodigo().equals(idBuscado)) {
                Object[] fila = {
                    p.getCodigo(),
                    p.getNombre(),
                    p.getDescripcion(),
                    p.getCantidad(),
                    p.getPrecio(),};
                modeloTabla.addRow(fila);
            }
        }

        vista.getTblProducto().setModel(modeloTabla);
    }

    private void crearEditarProducto() {
        if (vista.getDialogProducto().getTitle().contentEquals("Crear")) {

            ModeloProducto p = new ModeloProducto();

            if (vista.getTxtcodigo().equals("") || vista.getTxtnombrepro().equals("") || vista.getTxtDescripcion().equals("") || vista.getTxtCantidad().equals("") || vista.getTxtPrecio().equals("")) {

                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");

            } else {
                String codigo = vista.getTxtcodigo().getText();
                String nombre = vista.getTxtnombrepro().getText();
                String descripcion = vista.getTxtDescripcion().getText();
                String cantidad = vista.getTxtCantidad().getText();
                String precio = vista.getTxtPrecio().getText();

                if (codigoExiste(codigo)) {
                    JOptionPane.showMessageDialog(null, "El codigo ya existe. Por favor, ingrese un codigo diferente.");
                } else if (!validarCodigo(codigo)) {
                    JOptionPane.showMessageDialog(null, "La cédula debe tener 5 dígitos.");
                } else if (!validarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "El nombre debe ser valido");
                } else if (!validarDescripcion(descripcion)) {
                    JOptionPane.showMessageDialog(null, "La descripcion debe ser valida");
                } else if (!validarCantidad(cantidad)) {
                    JOptionPane.showMessageDialog(null, "Debe ser digitos numericos");
                } else if (!validarPrecio(precio)) {

                } else {
                    p.setCodigo(codigo);
                    p.setNombre(nombre);
                    p.setDescripcion(descripcion);
                    p.setCantidad(cantidad);
                    p.setPrecio(precio);
                    if (p.grabarProducto()) {
                        limpiar();
                        JOptionPane.showMessageDialog(vista, "DATOS CREADOS");
                        vista.getDialogProducto().setVisible(false);
                        cargaProductos();
                    } else {
                        JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
                    }
                }
            }
        } else if (vista.getDialogProducto().getTitle().contentEquals("Editar")) {

            ModeloProducto p = new ModeloProducto();

            if (vista.getTxtcodigo().equals("") || vista.getTxtnombrepro().equals("") || vista.getTxtDescripcion().equals("") || vista.getTxtCantidad().equals("") || vista.getTxtPrecio().equals("")) {

                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");

            } else {
                String codigo = vista.getTxtcodigo().getText();
                String nombre = vista.getTxtnombrepro().getText();
                String descripcion = vista.getTxtDescripcion().getText();
                String cantidad = vista.getTxtCantidad().getText();
                String precio = vista.getTxtPrecio().getText();

                if (!validarCodigo(codigo)) {
                    JOptionPane.showMessageDialog(null, "La cédula debe tener 5 dígitos.");
                } else if (!validarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "El nombre debe ser valido");
                } else if (!validarDescripcion(descripcion)) {
                    JOptionPane.showMessageDialog(null, "La descripcion debe ser valida");
                } else if (!validarCantidad(cantidad)) {
                    JOptionPane.showMessageDialog(null, "Debe ser digitos numericos");
                } else if (!validarPrecio(precio)) {

                } else {
                    p.setCodigo(codigo);
                    p.setNombre(nombre);
                    p.setDescripcion(descripcion);
                    p.setCantidad(cantidad);
                    p.setPrecio(precio);
                    if (p.ModificarProductos()) {
                        limpiar();
                        JOptionPane.showMessageDialog(vista, "DATOS CREADOS");
                        vista.getDialogProducto().setVisible(false);
                        cargaProductos();
                    } else {
                        JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
                    }
                }
            }

        } else if (vista.getDialogProducto().getTitle().contentEquals("Eliminar")) {
            ModeloProducto p = new ModeloProducto();
            p.setCodigo(vista.getTxtcodigo().getText());
            if (p.EliminarProducto()) {

                limpiar();
                JOptionPane.showMessageDialog(vista, "DATOS ELIMINADOS");

                vista.getDialogProducto().setVisible(false);
                cargaProductos();

            } else {
                JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
            }

        }
    }

    private void limpiar() {

        vista.getTxtnombrepro().setText("");
        vista.getTxtcodigo().setText("");
        vista.getTxtCantidad().setText("");
        vista.getTxtPrecio().setText("");

        vista.getTxtDescripcion().setText("");
        vista.getTxtcodigo().setEnabled(true);

    }

    private void abrirDialogo(String ce) {

        vista.getDialogProducto().setLocationRelativeTo(null);
        vista.getDialogProducto().setSize(750, 600);
        vista.getDialogProducto().setTitle(ce);
        vista.getDialogProducto().setVisible(true);
        if (vista.getDialogProducto().getTitle().contentEquals("Crear")) {

        } else if (vista.getDialogProducto().getTitle().contentEquals("Editar")) {

            LlenarDatos();

        } else if (vista.getDialogProducto().getTitle().contentEquals("Eliminar")) {
            LlenarDatos();
        }
    }

    private void cargaProductos() {
        DefaultTableModel mJtable;
        mJtable = (DefaultTableModel) vista.getTblProducto().getModel();
        mJtable.setNumRows(0);
        List<Producto> listaP = modelo.listarProductos();
        listaP.stream().forEach(p -> {
            String[] rowData = {p.getCodigo(), p.getNombre(), p.getDescripcion(), p.getCantidad(), p.getPrecio()};
            mJtable.addRow(rowData);
        }
        );
    }

    public void LlenarDatos() {

        List<Producto> listper = modelo.listarProductos();
        int selectedRow = vista.getTblProducto().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para que los datos se llenen, debe seleccionar un elemento de la tabla");
        } else {
            String selectedId = vista.getTblProducto().getValueAt(selectedRow, 0).toString();
            Optional<Producto> matchingProducto = listper.stream()
                    .filter(p -> selectedId.equals(p.getCodigo()))
                    .findFirst();

            if (matchingProducto.isPresent()) {
                Producto p = matchingProducto.get();
                vista.getTxtcodigo().setText(p.getCodigo());
                vista.getTxtcodigo().setEnabled(false);
                vista.getTxtnombrepro().setText(p.getNombre());
                vista.getTxtDescripcion().setText(p.getDescripcion());
                vista.getTxtPrecio().setText(p.getPrecio());
                vista.getTxtCantidad().setText(p.getCantidad());

            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    public void salir() {
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);

        Controlador.ControladorPrincipal control = new ControladorPrincipal(menu);
        control.iniciacontrol();
        this.vista.dispose();
    }

    private boolean codigoExiste(String codigo) {
        List<Producto> listaproductos = modelo.listarProductos();

        for (Producto producto : listaproductos) {
            if (producto.getCodigo().equals(codigo)) {
                return true;
            }
        }

        return false;
    }

    public boolean validarNombre(String nombre) {

        return nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,50}");
    }

    public boolean validarDescripcion(String descripcion) {

        return descripcion.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,99}");
    }

    public boolean validarCodigo(String codigo) {

        return codigo.matches("\\d{5}");
    }

    public boolean validarPrecio(String precio) {

        return precio.matches("\\d+(\\.\\d+)?");
    }

    public boolean validarCantidad(String cantidad) {

        return cantidad.matches("\\d+");
    }
}
