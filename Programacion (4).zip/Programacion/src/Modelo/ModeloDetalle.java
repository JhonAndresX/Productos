/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class ModeloDetalle extends DetalleFac {

    ConexionPostgres CPG = new ConexionPostgres();

    public ModeloDetalle() {

    }

    public List<DetalleFac> listadetalle() {
        List<DetalleFac> listadetalle = new ArrayList<DetalleFac>();

        try {
            String sql = "select * from detallefactura";
            ResultSet rs = CPG.consultaBD(sql);
            while (rs.next()) {
                DetalleFac deta = new DetalleFac();

                deta.setIddetalle(rs.getString("id"));
                deta.setIdfactura(rs.getString("id_factura"));
                deta.setProducto(rs.getString("producto"));
                deta.setCantidad(rs.getInt("cantidad"));
                deta.setPrecio(rs.getDouble("precio"));
                deta.setTotal(rs.getDouble("total"));

                listadetalle.add(deta);

            }
            rs.close();//CIERRO CONEXION
            return listadetalle;
        } catch (SQLException ex) {
            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public boolean grabarDetalle() {
        String sql;
        sql = "INSERT INTO detallefactura(id,id_factura,producto,cantidad,precio,total)";
        sql += "VALUES('" + getIddetalle() + "','" + getIdfactura() + "','" + getProducto() + "','" + getCantidad() + "','" + getPrecio() + "','" + getTotal() + "')";
        return CPG.accionBD(sql);

    }

    public boolean ModificarDetalle() {
        String sql;
        sql = "update detallefactura set id='" + getIddetalle() + "' ,id_factura='" + getIdfactura() + "' ,producto='" + getProducto() + "' ,cantidad='" + getCantidad() + "',precio='" + getPrecio() + "',total='" + getTotal() + "'where id='" + getIddetalle() + "';";

        return CPG.accionBD(sql);

    }


    public boolean EliminarDetalle() {
        String sql;
        sql = "delete from detallefactura where id='" + getIddetalle() + "';";
        return CPG.accionBD(sql);

    }

}
