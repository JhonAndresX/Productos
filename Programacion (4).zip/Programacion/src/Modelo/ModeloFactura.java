/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class ModeloFactura extends EncabezadoFac {

    ConexionPostgres CPG = new ConexionPostgres();

    public ModeloFactura() {

    }

    public List<EncabezadoFac> listaEncabezado() {
        List<EncabezadoFac> listaFac = new ArrayList<EncabezadoFac>();

        try {
            String sql = "select * from encfactura";
            ResultSet rs = CPG.consultaBD(sql);
            while (rs.next()) {
                EncabezadoFac fac = new EncabezadoFac();
                fac.setIdfactura(rs.getString("idfactura"));
                fac.setFecha(rs.getDate("fecha"));
                fac.setTotal(rs.getDouble("total"));
                fac.setCliente(rs.getString("cliente"));

                listaFac.add(fac);

            }
            rs.close();//CIERRO CONEXION
            return listaFac;
        } catch (SQLException ex) {
            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public boolean grabarEncabezado() {
        String sql;
        sql = "INSERT INTO encfactura(idfactura,fecha,total,cliente)";
        sql += "VALUES('" + getIdfactura() + "','" + getFecha() + "','" + getTotal() + "','" + getCliente() + "')";
        return CPG.accionBD(sql);

    }

    public boolean ModificarEncabeza() {
        String sql;
        sql = "update encfactura set idfactura='" + getIdfactura() + "' ,fecha='" + getFecha() + "',total='" + getTotal() + "',cliente='" + getCliente() + "'where idfactura='" + getIdfactura() + "';";

        return CPG.accionBD(sql);

    }

    public boolean EliminarEncabeza() {
        String sql;
        sql = "delete from encfactura where idfactura='" + getIdfactura()+ "';";
        return CPG.accionBD(sql);

    }

}
