/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class ModeloProducto extends Producto {

    Modelo.DetalleFac det = new DetalleFac();

    ConexionPostgres CPG = new ConexionPostgres();

    public ModeloProducto() {

    }

    public List<Producto> listarProductos() {
        List<Producto> listaproductos = new ArrayList<Producto>();

        try {
            String sql = "select * from productos";
            ResultSet rs = CPG.consultaBD(sql);
            while (rs.next()) {
                Producto producto = new Producto();
                producto.setCodigo(rs.getString("codigo_producto"));
                producto.setNombre(rs.getString("nombre_producto"));
                producto.setDescripcion(rs.getString("descripcion_producto"));
                producto.setCantidad(rs.getString("cantidad_producto"));
                producto.setPrecio(rs.getString("preciou_producto"));

                listaproductos.add(producto);

            }
            rs.close();//CIERRO CONEXION
            return listaproductos;
        } catch (SQLException ex) {
            Logger.getLogger(ModeloProducto.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public boolean grabarProducto() {
        String sql;
        sql = "INSERT INTO productos(codigo_producto,nombre_producto,descripcion_producto,cantidad_producto,preciou_producto)";
        sql += "VALUES('" + getCodigo() + "','" + getNombre() + "','" + getDescripcion() + "','" + getCantidad() + "','" + getPrecio() + "')";
        return CPG.accionBD(sql);

    }

    public boolean ModificarProductos() {
        String sql;
        sql = "update productos set codigo_producto='" + getCodigo() + "' ,nombre_producto='" + getNombre() + "',descripcion_producto='" + getDescripcion() + "',cantidad_producto='" + getCantidad() + "',preciou_producto='" + getPrecio() + "'where codigo_producto='" + getCodigo() + "';";

        return CPG.accionBD(sql);

    }

    public boolean ModificarCantidad() {
        String sql;
        sql = "update productos set codigo_producto='" + getCodigo() + "',cantidad_producto='" + getCantidad() + "' - '" + det.getCantidad() + "'where codigo_producto='" + getCodigo() + "';";

        return CPG.accionBD(sql);

    }

    public boolean EliminarProducto() {
        String sql;
        sql = "delete from productos where codigo_producto='" + getCodigo() + "';";
        return CPG.accionBD(sql);

    }

}
