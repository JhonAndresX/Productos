/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;

/**
 *
 * @author ASUS
 */
public class Persona {
    private String id_persona;
    private String nombres;
    private String apellido;
    private Date fecha_Nac;
    private String telefono;
    private String sexo;
    private String sueldo;
    private String cupo;
     private int edadPersona;

    public Persona() {
    }

    public Persona(String id_persona, String nombres, String apellido, Date fecha_Nac, String telefono, String sexo, String sueldo, String cupo) {
        this.id_persona = id_persona;
        this.nombres = nombres;
        this.apellido = apellido;
        this.fecha_Nac = fecha_Nac;
        this.telefono = telefono;
        this.sexo = sexo;
        this.sueldo = sueldo;
        this.cupo = cupo;
    }

    public int getEdadPersona() {
        return edadPersona;
    }

    public String getId_persona() {
        return id_persona;
    }

    public void setId_persona(String id_persona) {
        this.id_persona = id_persona;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Date getFecha_Nac() {
        return fecha_Nac;
    }

    public void setFecha_Nac(Date fecha_Nac) {
        this.fecha_Nac = fecha_Nac;
        LocalDate ldate = fecha_Nac.toLocalDate();
        Period periodo = Period.between(ldate, LocalDate.now());
        this.edadPersona=periodo.getYears();
    }
    

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getSueldo() {
        return sueldo;
    }

    public void setSueldo(String sueldo) {
        this.sueldo = sueldo;
    }

    public String getCupo() {
        return cupo;
    }

    public void setCupo(String cupo) {
        this.cupo = cupo;
    }
      
}
