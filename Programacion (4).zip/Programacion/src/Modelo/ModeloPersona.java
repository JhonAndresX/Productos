/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class ModeloPersona extends Persona {

    ConexionPostgres CPG = new ConexionPostgres();

    public ModeloPersona() {

    }

    public List<Persona> listarPersonas() {
        List<Persona> listaPersona = new ArrayList<Persona>();

        try {
            String sql = "select * from persona";
            ResultSet rs = CPG.consultaBD(sql);
            while (rs.next()) {
                Persona persona = new Persona();
                persona.setId_persona(rs.getString("id_persona"));
                persona.setNombres(rs.getString("nombres"));
                persona.setApellido(rs.getString("apellido"));
                persona.setFecha_Nac(rs.getDate("fechanacimiento"));
                persona.setTelefono(rs.getString("telefono"));
                persona.setSexo(rs.getString("sexo"));
                persona.setSueldo(rs.getString("sueldo"));
                persona.setCupo(rs.getString("cupo"));
                listaPersona.add(persona);

            }
            rs.close();//CIERRO CONEXION
            return listaPersona;
        } catch (SQLException ex) {
            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public boolean grabarPersona() {
        String sql;
        sql = "INSERT INTO persona(id_persona,nombres,apellido,fechanacimiento,telefono,sexo,sueldo,cupo)";
        sql += "VALUES('" + getId_persona() + "','" + getNombres() + "','" + getApellido() + "','" + getFecha_Nac() + "','" + getTelefono() + "','" + getSexo() + "','" + getSueldo() + "','" + getCupo() + "')";
        return CPG.accionBD(sql);

    }

    public boolean ModificarPersona() {
        String sql;
        sql = "update persona set id_persona='" + getId_persona() + "' ,nombres='" + getNombres() + "',apellido='" + getApellido() + "',fechanacimiento='" + getFecha_Nac() + "',telefono='" + getTelefono() + "',sexo='" + getSexo() + "',sueldo='" + getSueldo() + "',cupo='" + getCupo() + "'where id_persona='" + getId_persona() + "';";

        return CPG.accionBD(sql);

    }

    public boolean EliminarPersona() {
        String sql;
        sql = "delete from persona where id_persona='" + getId_persona() + "';";
        return CPG.accionBD(sql);

    }
    

}
