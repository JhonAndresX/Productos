/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class EncabezadoFac {
    private String idfactura;
    private Date fecha;
    private double total;
    private String cliente;

    public EncabezadoFac() {
    }

    public EncabezadoFac(String idfactura, Date fecha, double total, String cliente) {
        this.idfactura = idfactura;
        this.fecha = fecha;
        this.total = total;
        this.cliente = cliente;
    }

    public String getIdfactura() {
        return idfactura;
    }

    public void setIdfactura(String idfactura) {
        this.idfactura = idfactura;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    
}
